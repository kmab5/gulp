# Change log

## 0.5.0-phase5 · 2026-10-20
- Two native Glance launcher widgets, direct actions using Room and refresh on record/date changes.
- Settings accessibility preferences persisted with DataStore; improved reduced-motion nav.
- Secure system-document CSV export and explicitly confirmed delete-all action.
- Repository CSV/delete tests, widget manifest checks, Phase 5 docs and CI artifact naming.
- Full Android build and device QA still pending; no APK claimed.

# gulp changelog

## 0.4.0-phase4 · 2026-10-20
- Added first-run onboarding, opt-in reminders and local awake/quiet schedule.
- Added Room-linked Review charts and statistics of actual saved records.
- Added optional logged-beverage tracking reference and clinician-managed flag; visual fill scale remains independent.
- Added permission-aware Android inexact one-shot alarms, explicit notification actions, reboot/timezone rescheduling, snooze and recent-drink suppression.
- Added DataStore-backed single-use notification action tokens to avoid duplicate log actions on redelivery/double taps.
- Added domain and integration-contract tests, device test checklist, science guardrail documentation.
- All previous Home, History and water-engine sources retained.

## 0.3.0-phase3
- Room drink tracking, undo, date history and DataStore Home layout.

## 0.2.0-phase2
- Procedural animated water, tilt/touch reactions, waterline text contrast.

## 0.1.0-phase1
- Kotlin/Compose project foundation and five-tab shell.
