# STILLWATER · Design exploration 02

**Status: UNAPPROVED exploration only. No Android development was started.**

Screens: 01 Home, 02 Reminders, 03 History, 04 Settings, 05 Quick add, 06 Custom amount, 07 Edit home, 08 Tilted water, 09 Android widgets, 10 Empty home, 11 Full home.

All screen captures are custom static HTML/CSS mockups. They are **not** generated from or built into an Android application. Visual effects shown as snapshots; motion, gravity, blur fidelity, contrast transitions and actual widget interaction have not been tested.

## Acceptance questions

- Is the all-screen bottle direction right?
- Does the primary add action have sufficient prominence and location?
- Does the home feel customizable but not cluttered?
- Do waterline typography and submerged navigation feel natural?
- Should the remaining tabs be calmer or equally immersive?
- Is the color direction worth refining, or should we explore a totally different palette?

## Rules

- No slogan/poetic headline and no roman-number section labels.
- Sans-serif typography everywhere.
- Navigation uses Home, Reminders, History, Settings.
- Bottom nav stays visually under a decorative liquid bed; only level above baseline can track logged-fluid proportion.
- Water amount reflects *logged* drinks against a user-selected reference, never clinical hydration.
- Reorganizable Bento-style tiles have deliberate edit mode, snapping and resize constraints.
- Tilt response must be low-amplitude, spring-smoothed, battery-conscious, and disabled for reduced-motion preference.
- Transition target: non-physical UI fades/expands ~200-350 ms; liquid motion ~650-1200 ms with inertial damping, not aggressive bounces. Exact timings remain subject to design/prototype testing.
- Use two-layer typography with animated water mask so colors change gradually *where surface crosses text*. No hard text color flip.
- Active navigation pill is slightly raised with a frosted backing. For battery/performance, cap blur radius adaptively and have fallback.
- All essential controls are legible above and below water with contrast checks.
- Widgets are native Android components in release scope; images here are conceptual.
