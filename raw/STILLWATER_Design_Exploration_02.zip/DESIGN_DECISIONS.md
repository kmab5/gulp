# STILLWATER — Design review 02 (unapproved)

## What changed after the previous rejected visual direction

- Removed serif typography, literary slogans, decorative status dot, roman-numeral headings, the unexplained radar graphic, archaic controls, and brand terminology from navigation.
- Moved to a full-screen liquid bottle, with subtle glass edge and bounded fluid interaction.
- Put **Add a drink** in a high-contrast, visible top CTA. User-defined amount/drink presets occupy resizable tiles below.
- Bottom navigation: **Home · Reminders · History · Settings**. Background almost transparent; soft submerged styling; raised rounded-square active indicator with frosted blur.
- Preserved 4Rs only as **product design language**: Ritual, Rhythm, Road, Reflection. They are not navigation text.
- Prepared main tabs + overlays/states + widgets as static mockup images, NOT an Android prototype.
- Removed ornamental rings from Reminders after user specifically rejected a radar-like ornament.

## Visual system hypotheses, NOT final decisions

- Deep navy above liquid and bright turquoise below; organic low-amplitude water shape; border sheen implies enclosing glass/bottle.
- Inter, sans. Strong, short labels, no slogans. No text if it cannot help the user act.
- Bottled-water level is a **recorded intake visualization**, not a measured hydration state. Minimum decorative water behind nav never counts as recorded fluid. The tracked region above the baseline rises when drinks are logged.
- Text and icons receive masked light/dark layers crossing the waterline; no sudden color switches.
- Fluid surface filters phone orientation with damped spring/inertia and clamps angle so text is still readable. Water tilt is opt-in if accessibility/motion or sensor battery constraints call for it.
- Scroll, menus, grid reordering, changing tabs, water level, taps, sheets: physically coherent motion; no scale/pop/canned bouncing.

## Motion review targets (proposed, not measured)

- Press feedback: immediate color or surface compression, settle in ~180–240 ms; no spring overshoot for primary CTA.
- Add beverage: surface rises gradually ~700–1100 ms with very small damped ripples; discreet success state; undo easily.
- Tabs: active frosted indicator glides ~240–320 ms; scenes crossfade in a coordinated 220–360 ms; fluid surface persists without snapping.
- Bottom sheets: ease into position ~300–420 ms with background defocus; keyboard focus stays inside.
- Grid edit: hold to enter, drag item, neighbors flow organically and settle in <350 ms; resize handles + safe min/max tile sizes; accessibly reorder by buttons.
- Orientation sensor: filtered to remove jitter (e.g. ~6–10 Hz visual updates, proportional damping); cap visible surface angle; respect reduced-motion and battery saver. These are UX intentions, not validated sensor or timing specs.
- Home widgets are Android system widgets, not tiny copies of a running physics renderer.

## Check before moving to implementation

1. Visual approval of color family, typography, density, transparency, and main button.
2. Functional screen flow approval of all four main tabs + entry sheets + customization.
3. Separate design pass for onboarding, an individual drink detail/edit, reminder snooze/pause, preferences and notification designs.
4. Motion storyboard with frame-by-frame waterline, tilt and cross-water typography; reduced-motion variant.
5. Only then architecture/tech decisions and Android proof-of-concept.

## Referenced inspiration

The bento-like tile reorder/resize idea was inspired by lnk.moe, described by its creator as a bento-style drag/drop link-in-bio builder: https://www.robi.work/ . We borrow the idea, not assets, logos or styling.
