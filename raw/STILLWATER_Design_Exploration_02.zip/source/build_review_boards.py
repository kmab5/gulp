from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
import zipfile
P=Path('/mnt/data/stillwater_design_round2')
S=P/'screens'
fontdir='/usr/share/fonts/opentype/inter/'
regular=ImageFont.truetype(fontdir+'Inter-Medium.otf',20)
heavy=ImageFont.truetype(fontdir+'InterDisplay-SemiBold.otf',33)
small=ImageFont.truetype(fontdir+'Inter-Regular.otf',17)
sets={
 'board_01_tabs.png': [('01_home','Home'),('02_reminders','Reminders'),('03_history','History'),('04_settings','Settings')],
 'board_02_water_states.png': [('10_empty_home','Empty'),('01_home','Part-filled'),('11_full_home','High intake'),('08_tilted_water','Phone tilted')],
 'board_03_interactions.png': [('05_quick_add','Add a drink'),('06_custom_amount','Custom amount'),('07_edit_home','Edit home')],
 'board_04_widgets.png': [('09_android_widgets','Android widgets')],
}
for name,entries in sets.items():
 gap=30; outer=36; pw=430; ph=932; count=len(entries); title_h=118; label_h=57
 w=outer*2+pw*count+gap*(count-1)
 h=outer+title_h+ph+label_h+outer
 base=Image.new('RGB',(w,h),(8,20,34)); d=ImageDraw.Draw(base)
 d.text((outer,outer),'STILLWATER  /  DESIGN REVIEW 02',font=small,fill=(132,174,195))
 heading={'board_01_tabs.png':'Main tabs','board_02_water_states.png':'Water levels & movement','board_03_interactions.png':'Add water & edit home','board_04_widgets.png':'Home-screen widgets'}[name]
 d.text((outer,outer+30),heading,font=heavy,fill=(232,254,255))
 for i,(key,caption) in enumerate(entries):
  x=outer+i*(pw+gap); y=outer+title_h
  im=Image.open(S/(key+'.png')).convert('RGB').resize((pw,ph),Image.Resampling.LANCZOS)
  base.paste(im,(x,y))
  d.text((x+4,y+ph+17),caption,font=regular,fill=(213,242,250))
 base.save(P/name, optimize=True)
 print(name,base.size)
notes='''# STILLWATER — Design review 02 (unapproved)\n\n## What changed after the previous rejected visual direction\n\n- Removed serif typography, literary slogans, decorative status dot, roman-numeral headings, the unexplained radar graphic, archaic controls, and brand terminology from navigation.\n- Moved to a full-screen liquid bottle, with subtle glass edge and bounded fluid interaction.\n- Put **Add a drink** in a high-contrast, visible top CTA. User-defined amount/drink presets occupy resizable tiles below.\n- Bottom navigation: **Home · Reminders · History · Settings**. Background almost transparent; soft submerged styling; raised rounded-square active indicator with frosted blur.\n- Preserved 4Rs only as **product design language**: Ritual, Rhythm, Road, Reflection. They are not navigation text.\n- Prepared main tabs + overlays/states + widgets as static mockup images, NOT an Android prototype.\n- Removed ornamental rings from Reminders after user specifically rejected a radar-like ornament.\n\n## Visual system hypotheses, NOT final decisions\n\n- Deep navy above liquid and bright turquoise below; organic low-amplitude water shape; border sheen implies enclosing glass/bottle.\n- Inter, sans. Strong, short labels, no slogans. No text if it cannot help the user act.\n- Bottled-water level is a **recorded intake visualization**, not a measured hydration state. Minimum decorative water behind nav never counts as recorded fluid. The tracked region above the baseline rises when drinks are logged.\n- Text and icons receive masked light/dark layers crossing the waterline; no sudden color switches.\n- Fluid surface filters phone orientation with damped spring/inertia and clamps angle so text is still readable. Water tilt is opt-in if accessibility/motion or sensor battery constraints call for it.\n- Scroll, menus, grid reordering, changing tabs, water level, taps, sheets: physically coherent motion; no scale/pop/canned bouncing.\n\n## Motion review targets (proposed, not measured)\n\n- Press feedback: immediate color or surface compression, settle in ~180–240 ms; no spring overshoot for primary CTA.\n- Add beverage: surface rises gradually ~700–1100 ms with very small damped ripples; discreet success state; undo easily.\n- Tabs: active frosted indicator glides ~240–320 ms; scenes crossfade in a coordinated 220–360 ms; fluid surface persists without snapping.\n- Bottom sheets: ease into position ~300–420 ms with background defocus; keyboard focus stays inside.\n- Grid edit: hold to enter, drag item, neighbors flow organically and settle in <350 ms; resize handles + safe min/max tile sizes; accessibly reorder by buttons.\n- Orientation sensor: filtered to remove jitter (e.g. ~6–10 Hz visual updates, proportional damping); cap visible surface angle; respect reduced-motion and battery saver. These are UX intentions, not validated sensor or timing specs.\n- Home widgets are Android system widgets, not tiny copies of a running physics renderer.\n\n## Check before moving to implementation\n\n1. Visual approval of color family, typography, density, transparency, and main button.\n2. Functional screen flow approval of all four main tabs + entry sheets + customization.\n3. Separate design pass for onboarding, an individual drink detail/edit, reminder snooze/pause, preferences and notification designs.\n4. Motion storyboard with frame-by-frame waterline, tilt and cross-water typography; reduced-motion variant.\n5. Only then architecture/tech decisions and Android proof-of-concept.\n\n## Referenced inspiration\n\nThe bento-like tile reorder/resize idea was inspired by lnk.moe, described by its creator as a bento-style drag/drop link-in-bio builder: https://www.robi.work/ . We borrow the idea, not assets, logos or styling.\n'''
(P/'DESIGN_DECISIONS.md').write_text(notes)
with zipfile.ZipFile('/mnt/data/STILLWATER_Design_Exploration_02.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(P.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(P))
print('zip refreshed')
