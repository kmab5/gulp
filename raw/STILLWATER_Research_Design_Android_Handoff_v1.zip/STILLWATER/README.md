# STILLWATER — THE TIDAL OBSERVATORY
**Round 01 + 02 · Research, product, design, and Android implementation handoff**  
**Prepared 2026-10-19** · **Status: design/architecture approved as proposals; app not yet implemented**

## Start here
This is a complete **planning and design handoff**, not an Android source repository or runnable APK. It preserves the original science-led product proposal, incorporates the two requested changes (the four Rs and widgets in initial release), chooses an expressive artistic direction, and makes an Android-first technology recommendation.

### Guiding proposition
> Make the experience magical. Make the science invisible. Make the actions effortless.

The core idea remains reminders at user-selected intervals, quick logging of beverages, and gentle reflection without unsupported claims about biological hydration.

### Product pillars: the four Rs
- **The Ritual:** logging a drink as a beautiful, zero-friction interaction.
- **The Rhythm:** respectful, adjustable reminder scheduling.
- **The Road:** an evolving visual world rewarding ongoing participation, without punitive streaks.
- **The Reflection:** truthful and beautiful records and trends.

### Locked product constraints
1. Android-first; meaningful offline operation; no account needed.
2. **Unconventional and interactive visual experience is the first design priority.**
3. Aggressive care about download size, rendering performance, and battery.
4. Native home-screen widgets are in **v1**.
5. Scientific humility: no universal 8-glass rule, inferred clinical hydration score, forced catch-up, or unverified personalized prescriptions.
6. Accessibility and low-power experiences are first-class, not afterthoughts.

### Navigation
| File | Contents |
| --- | --- |
| `00_PRODUCT/PRODUCT_CHARTER.md` | vision, positioning, four Rs, v1 scope |
| `01_SCIENCE/HYDRATION_RESEARCH.md` | foundational evidence and limitations |
| `01_SCIENCE/EVIDENCE_REGISTRY.csv` | source URLs, strength, and product implications |
| `01_SCIENCE/DECISION_RULES.md` | precise health/content behavior rules |
| `02_EXPERIENCE/INFORMATION_ARCHITECTURE.md` | IA and onboarding |
| `02_EXPERIENCE/USER_JOURNEYS.md` | key flows and edge cases |
| `02_EXPERIENCE/CONTENT_AND_COPY.md` | actual copy examples |
| `03_DESIGN/VISUAL_DIRECTION.md` | aesthetic thesis and alternative directions |
| `03_DESIGN/TOKENS_AND_COMPONENTS.md` | palette, type, design tokens |
| `03_DESIGN/MOTION_AND_INTERACTION.md` | gesture, animation, audio/haptics specs |
| `03_DESIGN/WIDGETS.md` | v1 Android widget family |
| `03_DESIGN/SCREEN_SPECS.md` | actionable screen structure |
| `04_ANDROID/STACK_DECISION.md` | framework tradeoffs and decision |
| `04_ANDROID/ARCHITECTURE.md` | module diagram, repository and state handling |
| `04_ANDROID/REMINDER_SCHEDULER.md` | scheduling state machine, policies, DST |
| `04_ANDROID/DATA_AND_PRIVACY.md` | entity schema, offline posture |
| `04_ANDROID/PERFORMANCE_AND_SIZE.md` | size budget and quality gates |
| `05_SKILLS/DISCOVERY.md` | verified external design skills and commands |
| `06_DELIVERY/BUILD_PLAN.md` | vertical slices, milestones, QA |
| `06_DELIVERY/ACCEPTANCE_CRITERIA.md` | testable launch readiness |
| `design_assets/tokens.json` | machine-readable token starter |
| `concept_lab/index.html` | **non-production interactive concept study**—open locally in browser |
| `concept_lab/README.md` | what prototype demonstrates and deliberately does not |

### Important decisions vs assumptions
**Decisions:** Android native Kotlin/Compose, custom procedural art; reminders are cues not prescriptions; widgets launch in first release. **Provisional:** working title, dark observatory direction, target minSdk 26, color values, interaction timings, and package-size budget. Validate with hardware before committing to 3D or third-party animation runtimes.

### Source discipline
External literature and documentation appear as links and short original paraphrases. No copyrighted papers, agent-skill source code, or proprietary font binaries are included. Skills are **researched and recommended**, not installed in this package. Verify their licenses and security posture before adoption. This ZIP's own planning documents and prototype are original, and no brand/trademark clearance is implied.
