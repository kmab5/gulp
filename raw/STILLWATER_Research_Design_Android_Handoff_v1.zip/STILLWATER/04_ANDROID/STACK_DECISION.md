# Architecture decision record ADR-001 · Native Kotlin/Compose + procedural renderer
**Decision:** Native Android, Kotlin, Jetpack Compose UI, Compose Canvas for broad support, optional AGSL `RuntimeShader` on Android 13+ with deterministic Canvas fallback; Room; DataStore; AlarmManager for approximate reminders; Kotlin coroutines/Flow; Glance for widgets. No backend in v1.

## Weighted decision criteria (subjective estimates, not measurements)
Weights: expressive custom graphics/gesture control **35%**; Android OS integration/widgets **25%**; binary and asset size **20%**; performance/offline correctness **10%**; developer iteration speed **10%**.

| Stack | Expression (35) | Android (25) | Size (20) | Performance (10) | Velocity (10) | Weighted/5 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Kotlin + Compose + AGSL/fallback | 4.5 | 5.0 | 4.2 | 4.5 | 3.5 | **4.49** |
| Flutter + CustomPainter/shaders + Kotlin widgets | 5.0 | 3.6 | 2.7 | 4.5 | 4.5 | **4.11** |
| React Native + Skia + native widgets | 4.5 | 3.4 | 2.4 | 3.7 | 4.2 | **3.76** |
| Unity/3D-heavy engine | 5.0 | 2.5 | 1.3 | 3.5 | 3.0 | **3.27** |

These are qualitative planning scores. **No runtime benchmark or release size measurement exists yet.** Native offers direct OS APIs and avoids shipping an entire additional cross-platform runtime. Flutter is strongest alternative if advanced cross-platform animation iteration later matters more than small Android binary and native widgets. Unity conflicts with app size/battery for this scope.

## Runtime plan
- `minSdk = 26` as provisional compatibility floor; AGSL only on API 33+, protected by runtime checks.
- Target SDK determined at implementation from current Google Play requirements (don't hardcode a potentially stale value in planning).
- UI uses Compose Material primitives only where they aid accessible controls; custom theming and bespoke Canvas form the visual language. Don't ship huge prebuilt art dependency libraries.
- Tier 1 scene: lightweight Compose Canvas visual for APIs 26–32 and devices with low performance.
- Tier 2 scene: AGSL fragment effects via RuntimeShader / ShaderBrush API 33+ for fluid interference, refractive highlights, aurora; avoid expensive multipass layers.
- A separate OpenGL ES renderer is **contingency only** if real-device prototypes prove AGSL/Canvas inadequate; do not pre-emptively build a game engine.

## Core dependencies (families, not frozen versions)
AndroidX Compose UI/foundation/animation, Activity, Lifecycle/ViewModel, Navigation Compose, Room, DataStore Preferences, Kotlin coroutines and Flow, Glance appwidget, Macrobenchmark/Baseline Profile, appropriate testing libraries. Add no networking, account stack, WebView, 3D engine, or analytics SDK in initial slice.

## Android-specific challenges
- Approximate reminders must survive lifecycle/reboot and OS power restrictions; WorkManager is not a guaranteed exact minute tick. Source: https://developer.android.com/about/versions/14/changes/schedule-exact-alarms
- Android 13+ notification runtime permission; explicit just-in-time consent and clear in-app off state.
- AGSL `RuntimeShader` is Android 13+; fallback required. Source: https://developer.android.com/develop/ui/views/graphics/agsl
- Glance is RemoteViews-based; doesn't run our full custom renderer. Source: https://developer.android.com/develop/ui/compose/glance
- R8/shrinking and App Bundle for download size. Source: https://developer.android.com/guide/topics/androidgo/optimize-size

## Why not use agent skills as an implementation dependency
The skills searched are **agent workflow instructions**. They do not magically extend Android's drawing APIs and many target web technology. We adapt their design judgment and audits, not CSS as runtime code.
