# Local model, privacy and report calculations

## Entities (conceptual Room tables)
```text
DrinkRecord(id UUID primary key, occurredAtEpochMs UTC,
  recordedAtEpochMs UTC, originalZoneId, beverageType enum/string,
  volumeMl int, note nullable, deletedAt nullable, version int)
Preferences(key/value via DataStore: wakeMinutes, sleepMinutes,
  reminderIntervalMinutes, preferredVesselMl, preferredBeverage,
  notificationEnabled, hapticEnabled, soundEnabled, visualQuality,
  reducedMotionOverride, referenceMode, customReferenceMl nullable)
ReminderDecision(id UUID, candidateInstant, state [scheduled/skipped/
  delivered/dismissed/snoozed/actioned], reason, createdAt)
RoadMilestone(id, unlockedAt, participationReason)
```

## Reporting truthfulness
Daily aggregation uses the timezone for the local day being viewed; store raw UTC timestamp so timezone conversions are reversible. Provide policy for past travel days (display in timezone of occurrence, or user's explicit chosen report timezone; select and document before launch). `loggedMl = SUM(active DrinkRecord.volumeMl)`, not inferred consumed volume. In reports, 'no records' differs from recorded 0 mL. Water-only subtotal optional, all beverages subtotal separate. Simple 7-day mean labels must state how no-entry days affect denominator; recommend 7-calendar-day logged-volume mean with missing-entry caveat AND 'days with entries', not presenting this as full intake.

## Privacy
No account, no background location, no advertising ID, no health-data export by default, no analytics SDK in initial release. Data stays device-local unless user explicitly exports. UI allows inspect/edit/delete/export CSV or JSON. If using Android Auto Backup, decide clearly whether beverage logs backup and expose privacy implications; consider encrypted backup / controlled restore later. Security review for widget logs accessible on unlocked launcher and notification text visibility.

## Export
JSON `schemaVersion`, unit normalization to mL, ISO UTC timestamp and original zone id. CSV human-readable fields with correct escaping. Delete flow must remove Room records/settings and cancel scheduled notifications / update widgets; no fake 'deleted' claim before transaction completes.
