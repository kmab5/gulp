# Android performance and distribution-size budget

## Goals (not yet measured)
- Play-delivered compressed package **target <=18 MB** to a common arm64 device; **stretch <=12 MB** after release R8 and asset optimization. These are ambitious **design constraints**, not measured claims. Measure both Android App Bundle Play delivery size and installed footprint separately.
- First useful UI ideally under 1.5 seconds warm and around 2.5 seconds cold on selected midrange test device (hypotheses to be revised from benchmark).
- Smooth main interactions targeted 60 FPS on defined midrange handset; static/30 FPS graceful mode when thermals, power save or graphics capabilities restrict.
- Idle/background decorative GPU usage: zero; don't schedule high-frequency widget refreshes.

## Budgets (initial envelope)
| Bucket | Compressed delivery budget |
| --- | ---: |
| Android code + Compose/Room/Glance + native overhead | <= 10.0 MB |
| Typography, icons, sound | <= 1.5 MB |
| Art textures + generated shader data | <= 1.0 MB |
| Misc/config/metadata and slack | <= 5.5 MB |
| **Total target** | **<= 18.0 MB** |

These are accounting targets, NOT measured sizes. Evaluate dependency transitivity and localization before enforcing.

## How to win
1. Procedural liquid surface using generated gradients, SDF curves, repeated linework and tiny texture noise. Avoid 4K animated videos and 3D mesh collections.
2. Shader source embedded as text or resources, not an engine.
3. Use one art design across routes with parameterized scene states, not four independent 3D worlds.
4. Compress sound and bundle one or two audio motifs; do not bundle stock-audio libraries.
5. Shrink/minify release builds with R8, resource shrinking, Play AAB, resource inspection and unused-dependency removal. Source: https://developer.android.com/guide/topics/androidgo/optimize-size
6. Use `drawWithCache`, remember shader instances, update uniforms without parsing every frame. Source: https://developer.android.com/agents/skills/jetpack-compose/jetpack-compose-performance/references/graphics-performance
7. Set frames idle when not interacting and screen is still; low-power mode static by default.
8. Measure Macrobenchmark startup/frame timings and Baseline Profiles. Sources: https://developer.android.com/topic/performance/benchmarking/macrobenchmark-overview and https://developer.android.com/topic/performance/baselineprofiles/create-baselineprofile

## Measurement gates
Gate A: first vertical slice package size + baseline idle battery; Gate B: effect level 1 & 2 profiles on 3 physical devices; Gate C: widgets/notifications lifecycle reliability; Gate D: accessibility and release AAB screenshot tests. Record per-device frame metrics, jank rate, memory peak, package delivered size, idle current/battery and thermal behavior, measured—not aspirational marketing.

## Test device matrix
API 26 fallback (emulator acceptable for features, hardware needed for GPU); API 32 Canvas; API 33+ AGSL; current Android stable device; midrange 60 Hz; high-end 120 Hz; small phone 320dp; foldable landscape; TalkBack/200% font; battery saver; notification off. Use physical hardware for actual GPU/battery benchmarking.
