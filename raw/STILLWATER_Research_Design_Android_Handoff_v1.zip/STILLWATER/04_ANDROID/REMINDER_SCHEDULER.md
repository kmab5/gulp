# Reminder scheduler · precise semantics, approximate OS delivery

## Terminology
**Candidate time** is when user's settings make a prompt eligible. **Delivered time** is when Android actually displays it. Display 'around HH:mm' when using inexact delivery. **Drink event** is user-recorded and independent of reminder occurrence. An interval is a user-preference, **not** a medical dose schedule.

## Default proposal
Awake: 08:00–22:00. Interval: 90 minutes. No amount tied to interval. Quiet hours prohibit reminders. This is a UI convenience preset only, not evidence of ideal frequency.

## Algorithm (candidate generation)
```text
compute_next_candidate(now, prefs, records, notification_history):
  if paused or notifications_off: return none
  convert current instant to user's selected local timezone
  determine active awake window (may cross midnight)
  if outside window: candidate = next awake-start (+ interval policy)
  else: candidate = next interval boundary anchored at awake-start
  apply selected minimum-interval, suppression-after-log, snooze,
       max-prompts-per-day, dismissed prompt rules (UX policy)
  if proposed candidate >= sleep boundary: roll to next awake window
  return earliest eligible candidate, uniquely identified
```

V1 candidate boundaries anchor to wake start; drinks within suppression window skip a due candidate but **do not reset the whole cadence** unless the user explicitly selects reset-on-log mode. Example: 08:00 wake, 90m => 09:30, 11:00, 12:30...; if drink at 09:20, 09:30 may be suppressed; next 11:00 remains. Do not schedule at exact wake time by default: first reminder comes after one interval.

## Android delivery strategy
Use `AlarmManager` inexact alarms (`setWindow` or `setAndAllowWhileIdle` only as justified) for next eligible candidate; reschedule on receipt, app setting changes, reboot and relevant timezone/time changes. Some systems defer alarms for power conservation. Avoid asking for broad special exact-alarm permission in v1; user explicitly values gentle, approximate cues. Exact alarms require additional special permission and policy, often denied by default on Android 14+: https://developer.android.com/about/versions/14/changes/schedule-exact-alarms

Do **not** use periodic WorkManager as a precise every-90-minute timer: WorkManager work is deferrable and its minimum periodic interval (15 minutes) is not an accuracy guarantee. Use it only for suitable maintenance tasks. Native `POST_NOTIFICATIONS` runtime consent needed for Android 13+; a channel and group strategy avoids notification spam.

## Idempotence and recovery
Each candidate has deterministic hash of local date/window anchor/slot, or persistent UUID. Notification BroadcastReceiver atomically marks dispatch handled, so duplicate system callbacks do not post duplicate nudges. Widget action's quick sip has its own user-action id; ensure no duplicate broadcast retries cause accidental multiple logs. Schedule one next alarm, not months of future alarms.

## Context/relevance suppression
Configurable suppression window before prompt (prototype: 20–30 min, **hypothesis**); max daily notifications; snooze 20/45/60 minutes chosen by user; after repeated dismissals ask if frequency should be reduced rather than auto-changing silently. No catch-up sequence for missed alarms. If numerical recording reference met, pause goal-oriented prompts; if routine-only reminders remain enabled by explicit user selection, don't infer need for more fluid.

## Edge tests
Awake 22:00 to 06:00; DST spring-forward nonexistent time; DST fall-back repeated hour; timezone travel; changed interval and system clock; device reboot; day rollover; permission denied/revoked; multiple notification actions; sip recorded right before reminder; snooze past quiet start; disabled exact alarms; battery saver/doze; process death; target reached; empty data. Tests assert *policy and user-visible state*, not impossible minute-accurate delivery.
