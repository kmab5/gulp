# System architecture — modular, local-first, renderer-independent

```
:app / startup / permission / navigation
  |-- :feature:ritual     // one-tap record, edit, undo
  |-- :feature:rhythm     // interval settings and schedule views
  |-- :feature:road       // visual participation evolution
  |-- :feature:reflection // truthful records and reports
  |-- :feature:atelier    // settings, data, evidence/about
  |-- :feature:widgets    // Glance widgets and action callbacks
  |-- :core:domain        // pure Kotlin models, policy, state machine
  |-- :core:data          // Room repository, DataStore
  |-- :core:reminders     // AlarmManager, BroadcastReceivers, notifications
  |-- :core:design        // tokens, standard composables, a11y
  `-- :core:world         // Compose Canvas + API-33 shader adapter / fallback
```

**Start with fewer Gradle modules if build overhead outweighs separation**: at minimum ensure domain logic, renderer and platform components are tested independently. No scene class should store or derive intake statistics. Renderers receive read-only `WorldState` and expose interactions as typed events.

## Data flow
Interaction → ViewModel intent → use-case/domain validation → Room transaction → Flow emission → updated UI/scene state → widget refresh and reminder reschedule event. If database write fails, no success ripple that implies saved data. Use optimistic press feedback, but defer committed confirmation until saved.

## State model
`UserPreferences`: wake/sleep, cadence, quiet mode, unit, vessel, notifications, reduced-motion, reference mode. `DrinkRecord`: immutable id, beverage type, amount ml, occurredAt UTC, capturedAt UTC, timezone at entry, edit history/mutation version optional. `SchedulerState`: next candidate id/time, suppression state, pause until, last handled id, dismissal. `RoadState`: cosmetics/participation milestones; decoupled from water total. `WorldState`: current section, time segment, gentle artifact phase, interaction velocity, event pulse; derived and not medical.

## Domain/use cases
`RecordDrink`, `UndoDrink`, `EditDrink`, `GetDailyRecord`, `GetWeeklyReflection`, `BuildReminderCandidates`, `HandleNotificationAction`, `CalculateRoadProgress`, `ExportData`, `DeleteData`. Each one unit-tested without UI.

## Error boundaries
DB failure → noncommittal UI error and retry; alarm scheduling unavailable → truthful state + approximate fallback; widget stale/host constraints → last snapshot/refresh; GPU unsupported → static or Canvas fallback; permission denied → continue without notifications. App remains usable when completely offline.

## External dependencies / telemetry
No account, network, or backend initially. Crash reporting if added later is consent/configuration-sensitive, sparing of private payloads, and never necessary for basic app usage. Test reproducible without cloud services.
