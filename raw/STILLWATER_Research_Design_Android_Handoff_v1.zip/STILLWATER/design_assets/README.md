# Art-direction captures

`ritual-screen.png`, `rhythm-screen.png`, `road-screen.png`, and `reflection-screen.png` were captured from the self-contained local `concept_lab/index.html`, running in headless Chromium at a 390×844 CSS-pixel viewport on 2026-10-19. These are **concept visuals** and not Android screenshots. They are not claims that the final Kotlin application exists or currently achieves the depicted visuals.

`mobile-concept.png` and `desktop-concept.png` show the standalone art study in mobile and desktop browser windows. The desktop presentation is a studio mockup; it is not a desktop-platform commitment.

The proposed full Android visual engine will use native Kotlin Compose/Canvas with optional API-33 AGSL shader enhancement and semantic native controls. Motion/performance/size are not validated by these images.
