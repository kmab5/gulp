# Copy deck (prototype-safe)

## First run
Hero: **A little world for an ordinary ritual.**
Description: **Gentle reminders. Beautiful moments. Your own rhythm.**
Wake prompt: **When does your day usually begin?**
Vessel: **What do you usually drink from?**
Interval: **How often would you like a reminder?**
Context: **These are gentle cues, not instructions to drink on command.**
Permission: **Allow reminders? You can always change this later.**
Reference: **Choose an optional recording reference, or skip it.**
Clarifier: **These numbers describe recorded drinks, not an assessment of hydration.**
Medical guard: **If a clinician has asked you to manage or limit fluids, use their instructions rather than a general reference.**

## Ritual
Primary action: **Record a drink**
Default action after vessel configured: **Log 250 mL water**
Confirmation: **250 mL logged.** / **Undo**
Error: **Couldn't save that drink. Try again.**
Today's statistic: **Logged today**
Next reminder: **Next gentle nudge around 14:30**

## Rhythm
Heading: **Your rhythm, your rules.**
Permission denied: **Reminders are off in Android settings. Logging still works.**
Quiet hours: **The Observatory rests while you do.**
Dismissed: **No problem. We'll try again later.**
Paused: **Reminders paused.**

## Road
Heading: **A road made of returns.**
Explainer: **This world changes as you explore and record, not as a measure of your health.**
After absence: **Good to have you back.**
Reward: **A new formation appeared in your Observatory.**

## Reflection
Heading: **What you recorded.**
No-entry day: **No drinks recorded.**
Week: **You recorded drinks on six days this week.**
Reference reached: **You reached your chosen logging reference.**
History: **You can edit any entry.**

## Prohibited copy
'You're X% hydrated'; 'hydrate now or harm yourself'; 'catch up 1.5 liters'; 'you drank nothing yesterday'; 'your kidney risk dropped'; 'optimal every 90 minutes'; 'drink X ml because it is 29°C'; 'your streak died'.

## Accessibility semantic equivalents
If visuals show currents responding to a sip, TalkBack announces **'Drink saved, 250 milliliters water'**, not decorative particle metaphors. Every ornamental affordance has conventional labelled alternative. Animation can stop without disabling the log action.
