# User journeys + edge cases

## J1 — First successful drink (target interaction, not timing promise)
Open Ritual → see central tide and log action → tap → remembered volume and type recorded locally transactionally → environment visibly responds without blocking input → snackbar / spoken confirmation offers Undo → widgets update event-driven. Log works even if fancy renderer unavailable, and without network.

## J2 — Correct a drink
Tap 'Undo' immediately, or Reflection → entry → Edit amount/type/time → recompute day aggregates and Road participation safely. Volume can never be negative; no double count from rapid repeated taps (use separate explicit taps with debouncing/undo awareness, not silently drop desired repeat drinks).

## J3 — Notification without coercion
Wake window begins → scheduler finds next eligible candidate → approximate Android alarm posts a notification if permission granted → actions 'Log usual drink', 'Later', 'Dismiss' → later respects delay; dismiss does not immediately nag; log is persisted even if process was killed. If permission missing, Rhythm shows state and app functions normally.

## J4 — Session while not thirsty
Notification → 'Not thirsty' / Dismiss → acknowledge and prevent aggressive re-prompts; no deficit recorded; next cue follows chosen policy.

## J5 — Days away
No logging days → Road remains beautiful; Reflection calls them 'no entries'; reopening displays welcome without guilt, no staged 'drink everything you missed'.

## J6 — Pause/quiet times
User chooses 22:00–08:00 → no reminders during quiet window (including crossing midnight). Sleeping schedule may cross timezone; calendar-local notation remains understandable. Reboot/clock change/timezone change recomputes candidates.

## J7 — Widget quick sip
Tap quick log widget → intent/action callback → idempotent local database transaction → current widget snapshot immediately updates → subtle state ack. If secure lock/unavailable state prevents write, open activity with pending action confirmation; don't fake successful record.

## J8 — Small phone, large text, slow GPU
Full composition scales to 320dp width; target never hides log/navigation behind immersive canvas. Font scaling 200%, TalkBack labels/rotor order, reduced motion, static mode, less-powerful GPU fallback. Landscape/tablet scales environment but primary action remains near thumb/accessible location.

## Exceptional scenarios
Notifications off, Doze, exact-alarm disallowed, OEM battery killers, no network, multiple widgets, rapid tap race, restoration from backup, bad wall-clock change, daylight-saving gaps/overlaps, system 12/24h formats, locale, zero entries, target disabled, high-volume input requiring correction, app killed, and partial database errors all receive explicit tests. Notification dispatch may be approximate and must never be promised to the minute.
