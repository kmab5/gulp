# Information architecture and progressive disclosure

## Primary navigation: four Rs in a persistent bottom compass
1. **Ritual** (brand name of main Sanctuary) — scene, next reminder, logged beverages, large one-tap entry.
2. **Rhythm** — future potential reminder positions on a day arc, wake/sleep window, snooze, interval selector, silence/pause mode.
3. **Road** — slow visual exploration, past fragments, gentle rewards, journey journal; participation-only unlocks.
4. **Reflection** — visual timeline, daily/weekly aggregate, record editing, explicit logged-vs-actual distinction.

**Atelier:** personalization/settings appears as secondary persistent small icon from all four contexts, not a fifth tab. The earlier concept had Sanctuary/Rhythm/Echoes/Atelier; in this revised four-R IA, the Road gets its own primary place, Reflection subsumes Echoes, and Atelier becomes secondary. This deliberate change preserves all functionality while honoring the 4Rs.

## One dominant action
A sculptural 'Log a drink' control is ALWAYS reachable from Ritual in thumb zone. On other tabs, a compact pill/log sheet is one tap away. Swipe to change usual vessel size; long press for drink selector, with visible conventional alternatives. Never make swipe/hold the only way.

## First run, 6 bite-size moments
1. Enter the Observatory; show single promise.
2. Awake window (wake/sleep; clear defaults editable).
3. Default vessel (glass or bottle, custom ml).
4. Reminder cadence: 60 / 90 / 120 / 180 min or custom; preset is arbitrary UX choice; no claims of optimum.
5. Optional tracking reference or reminders-only; restricted-fluid screening; notification consent explained contextually.
6. A harmless illustrative sip or actual first log (explicit choice); unveil response; explain undo.

No registration required. Default permissions remain opt-in. A clean skip path exists at every nonessential choice.

## Layout zones
- Immersive world: fills viewport and respects safe areas.
- Atmospheric status: tiny but legible top edge date/next reminder; can fade but remains accessible.
- Primary interaction: lower third, clear label plus an expressive physical affordance.
- Navigation: compact four-point compass dock at bottom; stable touch targets.
- Detailed quantities and history: reveal on user action, not always overlaid.

## Information hierarchy
1. What can I do? Log a drink.
2. What happened? Recorded volume, undo.
3. When next? Next possible reminder or paused.
4. What have I logged? Today's summary.
5. Optional deeper data, safety notes, advanced settings.

## Behavioral tone
Not a teacher, not a demanding coach, not an alarm bell. Warm, clear, short, respectful. Avoid medical claims and 'good/bad' day categorizations.
