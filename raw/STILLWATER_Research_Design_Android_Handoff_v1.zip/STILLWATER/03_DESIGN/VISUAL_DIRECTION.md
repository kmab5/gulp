# Design thesis — THE TIDAL OBSERVATORY

## One-sentence north star
**A pocket-sized impossible observatory: a living liquid artefact suspended inside an intimate architectural universe, touched like a physical instrument.**

## Why this and not a standard tracker
Most trackers use circles, flat glass icons, cheerful percentages and common gradient cards. This one uses a single compelling **kinetic artifact** as a navigable canvas. The background is not merely decoration: each touch creates a physically suggestive response; shifting time, day and recording activity change atmosphere. Actual data remains sober, literal, and accessible.

## Art direction: 'Liminal tidal cartography'
- Form: sculpted liquid torus/celestial lens floating over a contour-map basin; fine engraved lines and impossibly precise instrument ticks; natural asymmetry inside exact geometry.
- Space: dark negative space, focused spotlight, a portal-like focal point occupying ~60–72% of screen, peripheral instruments and quiet controls. Artboard behaves like a spatial composition, not vertical cards.
- Materials: ink-dark ceramic, satin metal, nacreous water, ghostly ripples, occasional warm coral/highlights. **Not general-purpose glassmorphism.**
- Physics: touch transfers momentum to currents; a sip becomes a ripple, a slow luminous filament, then calm. Every response is art, never a measure of bodily hydration.
- Light: pre-dawn soft mint, midday fine amber, evening lilac-tinted graphite, midnight deep petrol. Respect manual appearance mode, not only time.
- Typography: expressive high-contrast editorial display serif contrasted with highly legible functional sans. Never sacrifice label readability for artistry.
- Sonic personality: optional tiny ceramic/aqueous notes, spatial lightness; fully muted by default or discoverable during onboarding.

## The signature moment — RECORDING A SIP
Resting artifact looks still but alive → user taps illuminated recording pad → shallow meniscus indents under finger → brief water ripple expands through central artifact → thin concentric engraving shifts by a fraction → concise literal text '250 mL logged / Undo' is present throughout → subtle nonessential auditory and haptic punctuation if enabled → system returns to steady state. Interaction under ~700ms for the critical phase; long ambient settling may continue behind controls without blocking touch or requiring user to watch.

## Three candidate directions evaluated
| Direction | Unconventional | Native-size feasibility | Accessibility clarity | Decision |
| --- | --- | --- | --- | --- |
| Tidal Observatory / kinetic liquid instrument | High | High with procedural graphics | Strong with separate semantic overlay | **Chosen** |
| Micro-planet / fully modeled dream-world | Very high | Lower: 3D engine/assets/thermal cost | More difficult | Future experimental mode |
| Kinetic typographic monument | High | Very high | High | Secondary 'reduced effects' design language |

## Visual composition
Portrait home at 360×800dp: top 12% sparse time/next cue; center 60% artifact with visible negative space; bottom 28% one accessible action and four-point navigation. Texture density is maximized INSIDE art, not the content layer. The whole viewport is atmospherically filled; conventional navigation never disappears behind the artwork.

## Adaptive qualities
- Time of day changes sunward direction, hue and particle speed, **not medical claims**.
- Pointer drag imparts tiny angular momentum; tap drops a ripple; long press opens conventional quick settings; device orientation may shift parallax **only with explicit preference**, not mandatory sensor access.
- Drinking event changes world temporarily; Road progress has slow persistent morphology via earned non-volume-dependent participation stages.
- Quiet hours freeze energy rather than showing death/decay. No drinking logs is not represented as empty/desiccated landscape.

## Brand risks / guardrails
Unmistakable but approachable; ambitious but battery-responsible; strange composition with familiar actionable text; no forcing sensory effects; no addictive variable-reward pressure; no confusing implied medical visualization. Working name STILLWATER may require trademark check before publication.
