# Motion score, tactile UX, atmospheric system

## Motion grammar
1. **Echo** (50–120ms): immediate press deformation / visual and haptic acknowledgement.
2. **Ripple** (200–700ms): one purposeful nonlinear wave after a log / clear state transition.
3. **Drift** (10–30s while visible): slow background breathing, capped and omitted in power save/reduced motion.
4. **Threshold** (300–500ms): entering another R reorganizes the same world, instead of navigating to unrelated cards.
5. **Discovery** (800–1500ms max, skippable): rare Road unveil; never blocks critical log access.

Durations are **design hypotheses** and performance targets, not scientific results. Dynamic spring constants should be tuned on physical hardware. No unbounded particle systems. Prefer event-triggered effects over perpetual high-refresh animation.

## Touch contracts
- Single tap artifact: short ripple visual only; must not accidentally log water.
- Distinct labelled log pedestal: direct primary log action.
- Drag artifact: angular momentum, capped and smoothed, no navigation triggered by small drags.
- Pinch on Road: zoom visual archive; on Rhythm: timeline zoom as secondary navigation. Visible zoom controls for accessibility.
- Long press pedestal: alternate drink/amount sheet, always accessible via adjacent 'Change' action.
- Double tap dangerous as hidden drink action → **do not use**.
- Drag vs tap uses slop threshold and pointer cancellation to prevent surprise logging.
- Back gesture never hijacked; screen transitions respect Android predictive-back where supported.

## Haptic choreography
Tap action light tick; successful data commit one soft confirmation; failure clear distinct feedback; disabled when system or in-app haptics disabled. Not every background ripple uses a haptic. If haptic unavailable, behavior remains intelligible.

## Sound
Optional 30–200ms low-volume percussive water-like sine/ceramic accent synthesized or compressed (avoid MP3 pack bloat). Respect device Do Not Disturb, silent mode, accessibility, mute preference; never play audio from ordinary reminder notifications without user choice.

## Frame policy
- Display graphics only when scene visible; suspend clock when obscured / backgrounded.
- Normal target >= 60 FPS on midrange reference hardware; adaptive 30 FPS / event-only low-tier option; verify, do not promise universally.
- Shader passes: prefer <=2 full-screen layers; procedural gradients / SDF style shapes / thin engraved lines, small geometry.
- Record action always wins over animation rendering if compute budget tight.

## Reduce motion
Replace all continuous drift and zoom with near-static material; retain concise 80–150ms opacity/tactile changes or no animation, respecting Android animator settings and an independent in-app toggle. Do not require motion to discover controls.

## Failure/fallback experience
When GL/AGSL feature unsupported or expensive, render static 2D Canvas version of identical sculpture; same colors, silhouettes, labels, functionality. Treat fallback as intentionally designed 'ink edition', not degraded feature.
