# Visual tokens and components — v0 draft

## Colors (provisional, test contrast)
- `void` **#070B0F** — deep base.
- `ink` **#111B22** — raised ceramics.
- `abyss` **#113840** — deep liquid.
- `jade` **#54E0CB** — living currents / selected state; not sole information carrier.
- `chalk` **#F3EFE5** — main foreground.
- `mist` **#A9B7B9** — secondary foreground; verify accessibility against actual surfaces.
- `ember` **#F3A784** — event punctuation, not warning by default.
- `violet` **#B6ACED** — evening accent.
- `warning` **#FFC07C** and `error` **#FF827A** — semantic alerts.

## Type
- Display: conceptual editorial serif such as Fraunces (check proper redistribution/license and file weight); large 32–48sp; variable optical choices. Native serif fallback acceptable.
- Utility sans: device system / carefully selected lightweight variable font, 13–17sp, never tiny for key actions. Prefer built-in system type if size/legibility conflict.
- Numeric ledger: tabular numerals and clear `mL` / `L` units; decimal localization. No hidden meaning encoded in color only.
- Max 2 bundled typefaces; subset only within font licensing; do not package fonts in this design ZIP.

## Spatial scale
Base points 4, 8, 12, 16, 24, 32, 48 with deliberate asymmetry permitted for art region. 48dp minimum touch targets, prefer 56–64dp for main tap. 24dp+ outside-edge safe insets depending on device. Supports display cutouts and system bars.

## Surfaces
- `WorldPlane`: immersive graphics under accessible composable controls.
- `RecordPedestal`: text button with strong affordance and animated surrounding ornament; semantic native button node.
- `CompassDock`: four fixed named controls; never gesture-only. Active destination identifiable without color.
- `NeedleTime`: approximate next reminder label with icon + text.
- `VesselCarousel`: direct preset chips, editable number entry with validation.
- `DepthSheet`: lower sheet for detailed log, history, interval, and settings; focus-trapped as platform supports, dismissal predictable.
- `LedgerGlyph`: compact quantity and unit, usable at 200% font scale.
- `SceneSnapshot`: widget-compatible prerendered art state (not a fake animated widget).

## Layering
L0: procedural world; L1: low-contrast graduated readability veil; L2: essential controls; L3: sheets / modals; L4: accessibility overlays and Android notification surfaces. Content controls must never be rendered into a Canvas without semantics. Avoid shader dependency for text.

## States required on every component
Idle, pressed, focused (keyboard/accessibility), disabled, loading/saving, confirmed, error, reduced-motion/static, high-contrast, large text, screen reader. Transition spec documents travel, duration, easing, cancellation. Components must be operable with TalkBack and ordinary taps.

## Tokens starter
`design_assets/tokens.json` contains the app-specific starter values. These tokens are intended to seed Compose `ColorScheme`, dimensions, motion config, not blindly port CSS.
