# Widgets · First release, not future scope

## System constraint
Android home-screen widgets are composed through **Glance / RemoteViews**, not unrestricted Jetpack Compose with real-time procedural shaders. Present **composed snapshots** and conventional native widget actions; no live full-frame Canvas scene in launcher. Reference: https://developer.android.com/develop/ui/compose/glance/build-ui and https://developer.android.com/develop/ui/compose/glance/glance-app-widget

## Widget family (v1)
### W1 — 'Sip' / small 2×1
High contrast art background with **+250 mL** primary tap and optional small type icon. Action directly logs configured usual beverage and displays native acknowledgement / content refresh. Long press for widget settings handled by launcher as normal. Source of truth is Room, not widget cache.

### W2 — 'Orbit' / medium 4×2
Prerendered art thumbnail showing current Observatory phase, **logged today (mL)**, **next nudge around HH:mm**, a one-tap quick sip button. Snapshot updates when data changes or at restrained system schedule, not animated per second.

### W3 — 'Aperture' / large 4×3+ responsive
More atmospheric art, timeline marks for day, next reminder, quick log and open Rhythm or Reflection deep links. Clearly decorative scene, not physiological reservoir. Low contrast art never obscures numeric facts.

## Rules
- Widgets must work with app closed/without account or network.
- When widget logging succeeds: write transaction to DB; schedule relevant reminder suppression; dispatch widget update; show reasonable feedback. If failure, don't claim success.
- Use responsive size modes and provide widget-picker previews; configurable usual amount.
- Don't redraw widget backgrounds every few minutes solely for aesthetics. Event-driven refresh and platform-friendly periodic refresh only.
- Don't claim exact reminder timestamp if scheduling inexact: display 'around'.
- Multiple instances can have independent sizes; each uses same canonical data.
- Screen-reader content descriptions, 48dp-friendly tap regions where layouts allow, contrast, resize and battery validation.

## Widget implementation acceptance
Add/resize/remove each form factor; one-tap drink log; persistence after reboot; notification paused state; app updated; action under lock-screen considerations; repeated taps with unique user-intended events; launcher variation on Pixel/Samsung. Test RemoteViews behavior on device, not Compose preview only.
