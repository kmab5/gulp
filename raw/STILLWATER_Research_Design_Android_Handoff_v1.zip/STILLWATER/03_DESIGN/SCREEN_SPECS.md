# Screen-by-screen design and interaction spec

## R1 Ritual / Sanctuary
Visual: full-bleed instrument, sculpted tide at focus; decorative top 'day phase'. Functional overlay top 'Next nudge around 14:30'; near lower third 'Logged today: 1.25 L'; dominant accessible 'Log 250 mL water' pedestal. Secondary 'Change' opens beverage drawer; latest log allows Undo. Scrolling not required for key controls.

## R2 Rhythm
The central world becomes a 24-hour circular dial (not a conventional scheduler table). Sweep arc shows awake window, quiet hours, planned candidate prompts, recorded drink nodes. Active central card contains editable wake, sleep, interval; on/off/pause; reminder permissions. Pinch/drag explores dial, but a simple linear list is one button away; never gesture-only. Times stored/expressed in local time with day boundary annotations.

## R3 Road
Artifact reorganizes as living topographic atlas, a path made of sculptural fragments; slow progression is tied to **recording engagement** not cumulative volume. Each stage reveals a shape, faint engraved annotation or new ambient environmental variation. Decorative motifs persist if logging stops. Narrative labels: 'A road made of returns.' No reward for large drink sizes.

## R4 Reflection / Echoes
A horizontal, touch-explorable liquid ledger: one visible day at a time, week summaries on pull-up sheet, accurate entries and editing. Accessible plain tabular list always available. Chart titles 'Logged beverages' not 'hydration'. No-entry days explicitly separate from zero consumption. Date selector and export entry visible.

## Atelier / secondary
Themes, audio/haptics, reduced motion, high contrast, vessel, schedule, optional goal/reference, data/privacy, evidence explainer, safety note, support and app details. Deep-link accessible, not a fifth main place.

## Onboarding
Six-scene entry sequence described in IA, under ~1 minute for a confident user; accessible 'Skip' and editable values. Opening spectacle skippable, no mandatory audio, no location permission for weather.

## Overlays and notifications
Full-screen graphic layer never owns semantic notifications. Native notifications offer 'Log usual drink', 'Later', 'Dismiss'; rich visuals via small icon/brand colors, not invasive screens or full-screen intents. Respect Android permission and background restrictions.

## Android physical adaptability
Compact portrait, tall phone, foldable unfolded, split-screen, landscape, accessibility font 200%; use responsive world aspect, proper `WindowInsets` handling, and semantic overlays. Nothing clipped in 320dp compact layout. In large landscape, split world on left / ledger and action on right rather than simply stretching proportions.
