# Design/creative agent skills — discovery report
**Checked 2026-10-19** from Vercel's skills.sh directory and official GitHub repository. Directory install totals are dynamic and rounded, **not ratings**. User asked for 'good-rated' skills; skills.sh exposes install adoption, repository stars, and third-party audit badges, not verified user satisfaction review scores. Selection relies on source reputation, adoption, demonstrated workflow fit, and security inspection. Do not imply every skill directly supports native Kotlin.

## Discovery process
1. Read `vercel-labs/skills/skills/find-skills/SKILL.md` using GitHub: https://github.com/vercel-labs/skills/blob/main/skills/find-skills/SKILL.md . The method requires leaderboard first, CLI keyword search, then quality verification.
2. Read category leaderboard: https://www.skills.sh/topic/design and candidate descriptions. Used the directory search to cross-check results and GitHub sources. Attempted `npx --yes skills find 'mobile ui ux'` in this runtime; command returned no usable results, so CLI results are **not claimed**. All selections below are from publicly checked directory listing and pages.
3. Checked high-adoption individual listings for source suitability and security badges, including `impeccable` dependencies/prerequisites.
4. Avoided low-use, paid-API-dependent, or web-only special-purpose skills as primary Android guidance.

## Ranked useful skill stack
| Rank | Skill | Approx installs | Repo stars | Purpose for STILLWATER | Limitation |
| --- | --- | ---: | ---: | --- | --- |
| 1 | `anthropics/skills@frontend-design` | ~1.0M | ~181K | Commit to original art direction, visual grammar, unconventional hierarchy | web-first framing; adapt principles to Compose |
| 2 | `emilkowalski/skills@emil-design-eng` | ~363K | ~47K | Interaction timing, craftsmanship, motion polish | web-centric examples |
| 3 | `nextlevelbuilder/ui-ux-pro-max-skill@ui-ux-pro-max` | ~398K | ~136K | design systems, color/accessibility/UX checks | extremely broad; beware template drift |
| 4 | `pbakaus/impeccable@impeccable` | ~344K | ~83K | whole-product design context/critique prerequisites | audit status varies by provider; read scripts before executing |
| 5 | `pbakaus/impeccable@animate` | ~82K | ~83K | motion feedback, readable transitions | requires impeccable context |
| 6 | `pbakaus/impeccable@overdrive` | ~63K | ~83K | an intentionally unforgettable art/interaction pass | animation must stay within Android performance budget; context required |
| 7 | `pbakaus/impeccable@distill` | ~80K | ~83K | keep essential logging UX obvious underneath spectacle | requires impeccable context |
| 8 | `anthropics/skills@canvas-design` | ~119K | ~182K | develop visual movement/illustration studies | skill outputs mainly visuals, not production Android engine |

Sources: https://www.skills.sh/anthropics/skills ; https://www.skills.sh/emilkowalski/skills/emil-design-eng ; https://www.skills.sh/nextlevelbuilder/ui-ux-pro-max-skill/ui-ux-pro-max ; https://www.skills.sh/pbakaus/impeccable ; https://www.skills.sh/anthropics/skills/canvas-design . Individual counts change daily.

### Optional specialists
- `pbakaus/impeccable@critique` and `@polish` for ruthless visual review.
- `pbakaus/impeccable@adapt` for large-screen/responsive work.
- `pbakaus/impeccable@audit` for interaction/accessibility checks; verify manual Android accessibility since these are mostly web-first.
- `vercel-labs/agent-skills@web-design-guidelines` as secondary generic readability checks, not the main creative engine.

### Excluded from default
`sleekdotdesign/agent-skills@sleek-design-mobile-apps`: the directory shows ~13 installs at review time and a separate paid Pro+ API/auth dependency; unsuitable as a core reproducible local-first workflow. `React`-specific best-practices do not match chosen Kotlin production stack. Skills with suspicious shell-script execution or unverifiable licenses are not auto-installed.

## Suggested workflow at implementation
Discover → bold art concept via `frontend-design` + `canvas-design` → architect with Android platform docs → design prototype → `impeccable` context → `overdrive`/`animate` on the centerpiece → `distill` essential controls → native accessibility/performance tests → `critique` + `polish` every visual iteration. Keep the 4Rs and source-of-truth research docs in the agent's project context.

## Install examples (human-controlled)
```bash
npx skills add vercel-labs/skills --skill find-skills
npx skills find 'mobile ui ux'
npx skills find 'motion design'
npx skills find 'creative interface'
npx skills add anthropics/skills --skill frontend-design
npx skills add emilkowalski/skills --skill emil-design-eng
npx skills add nextlevelbuilder/ui-ux-pro-max-skill --skill ui-ux-pro-max
npx skills add pbakaus/impeccable --skill impeccable
npx skills add pbakaus/impeccable --skill animate
npx skills add pbakaus/impeccable --skill overdrive
npx skills add pbakaus/impeccable --skill distill
```
Never execute network-downloaded scripts or install agents' dependencies blindly. Inspect source files, dependencies, repository licenses, scoped permissions, and currently reported security audits first. Optional installation is deliberately left to the user's local project; this ZIP vendors none of these skills.
