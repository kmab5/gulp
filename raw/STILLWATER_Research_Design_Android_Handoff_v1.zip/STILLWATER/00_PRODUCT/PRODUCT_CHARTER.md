# Product Charter · STILLWATER

## Ambition
The most aesthetically ambitious water-drinking reminder app on Android, in which extravagance is the surface and simplicity is the function. The design is immersive enough to feel like a place, responsive to subtle changes in input, time, and history, and ergonomically intelligible on first use.

## The four Rs
- **Ritual:** 1–2 direct gestures should suffice to record the user's usual drink; editing, undo, and different beverages remain available.
- **Rhythm:** a self-chosen interval inside waking hours, with quiet hours, snooze/dismiss, adaptive suppression and immediate rescheduling.
- **Road:** environment evolves in response to participation over time, not to a purported physiological hydration level; missing days never destroy progress.
- **Reflection:** descriptive summaries of logged fluids, active recording days, common drinks, and rhythm settings. Never report unmeasured clinical facts.

**Mnemonic:** Ritual begins the action; Rhythm makes room for it; Road makes it memorable; Reflection helps it make sense.

## Core promise
Remember to drink. Log it easily. Observe your pattern. Return because the experience is worth returning to.

## Audience
Adults 18+ who want a more enjoyable way to remember to drink, especially those who appreciate experimental art and atmospheric interfaces. Not a therapeutic intervention or a medical monitoring device.

## Jobs to be done
- 'I want a friendly nudge while I'm awake.'
- 'I want to record the water or other beverages I had without fiddling with a form.'
- 'I want a truthful summary of the drinks I remembered to record.'
- 'I want something gorgeous, responsive, and calm—not a guilt-powered goal tracker.'

## Included in first release
- Art-directed interactive Sanctuary home; fluid-log ritual; undo and edit; multiple drink types and custom vessels.
- Rhythm settings: intervals, sleep/wake times, notification permission education, pause, snooze, dismiss, adaptive skip; safe behavior when permission withheld.
- Road: visual progression/collectible environmental memories that do not reset for missed days.
- Reflection: daily/weekly logged volumes, recording days, optional nonprescriptive tracking reference, labels that prevent false inference.
- Four surfaces / tabs; short onboarding; accessible alternative mode; audio/haptics on/off; local data export/delete.
- **V1 Android home-screen widgets:** quick sip, rhythm glance, atmospheric mini-scene in static/snapshot form.
- Local-first durable storage, offline operation, resilient app process/reboot recovery, basic test suite.

## Deliberately excluded from initial release
Accounts/cloud sync, smart-bottle integrations, wearables, AI intake prescriptions, social leaderboards, AI dehydration scoring, external weather-derived dosage, and dedicated pediatric/medical condition care paths.

## Business model
Not decided; don't introduce ads, behavioral dark patterns, forced sign-in, or subscription gates into research/UX assumptions. Monetization must not compromise safety or privacy.

## Risks
- Graphic spectacle obscures the one main action → permanent legible primary log action.
- High GPU/battery load → inactive scenes pause; quality tiers; shader fallback.
- Reminder unreliability → inexact scheduling with transparent timing and robust recovery.
- Gamification encourages overconsumption → reward participation, never volume escalation.
- Widgets require different rendering capabilities → ship prerendered atmospheric snapshots and native controls.

## Success criteria (initial product hypotheses)
Users can log a drink quickly and undo errors, recognize reminder timing, understand that history shows logged rather than actual intake, control notifications, use widgets without account, and enjoy the visuals on real Android devices. Research can test habit support, but that result must not be assumed.
