# Decision log

| ID | Decision | State | Why |
| --- | --- | --- | --- |
| D01 | The four Rs: Ritual / Rhythm / Road / Reflection | Accepted | memorable product philosophy and nav |
| D02 | Android widgets in first release | Accepted | strong daily utility / Android identity |
| D03 | Time-based prompts are cues, not evidence-driven drinking doses | Accepted | science and safety |
| D04 | Native Kotlin + Compose + Canvas + selective AGSL | Recommended | unique visual control, Android support, size |
| D05 | 18MB delivered budget | Provisional | ambitious design constraint; measurement pending |
| D06 | Tidal Observatory: liquid mechanical cartography | Recommended | distinctive, parameter-driven, packable |
| D07 | Road participation rewards not volume/streak punishment | Accepted | avoids pressure to overdrink |
| D08 | Four tab compass plus secondary Atelier | Recommended | honors four Rs and keeps settings reachable |
| D09 | minSdk 26 | Provisional | broad Android support with fallback; revisit device research |
| D10 | No login/network or AI health predictions in v1 | Recommended | safety, small size, privacy |
| D11 | Selected agent skills researched, not auto-installed | Accepted for handoff | security/reproducibility |
| D12 | Later medical-grade modes excluded from v1 | Accepted | no validation or clinical infrastructure |

Open design decisions: final brand naming/trademark, chosen licensed typography, actual material quality tiers, animation audio, initial default amount, wake window defaults, policy for travel-day timezone reporting, exact reporting averages, widget visual thumbnails. None blocks the first implementation spike.
