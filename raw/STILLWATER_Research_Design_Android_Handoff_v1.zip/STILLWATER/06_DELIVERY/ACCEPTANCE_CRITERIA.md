# Release acceptance criteria (testable)

## Functional
- [ ] Fresh install offline, no sign-in; all four Rs available and accurately labelled.
- [ ] Change vessel and log common beverages in <=2 deliberate taps from Ritual; add/edit/undo work after process kill/restart.
- [ ] No numerical reference required; if selected, clearly not a physiologic hydration grade.
- [ ] User-selected waking, sleeping, interval, pause and snooze alter next eligible reminder candidates reliably.
- [ ] Permission denied/revoked still permits normal app use and displays a clear reminder-disabled state.
- [ ] Android 13+ notifications permission, Doze, reboot, timezone/DST, scheduling restrictions covered by device/instrumented tests.
- [ ] No duplicate notification posts or accidental repeated widget saves from broadcast retries.
- [ ] Widgets 2×1/4×2/4×3 have useful design, quick logging and immediate refresh, with resize behavior and screen-reader actions.
- [ ] Reflection distinguishes zero entries from zero fluid consumption, describes logged volume, offers edits/export/delete.

## Design
- [ ] Hero scene is clearly unique rather than template UI; subtle gestures create physical response and don't trigger false logs.
- [ ] Hero's primary action legible at a glance on 320dp device, 200% font scale, and dark/light/high-contrast modes.
- [ ] All essential actions accessible without gesture discovery; TalkBack path clear; reduced motion and static visual mode function.
- [ ] World and labels retain hierarchy in split screen and tablet/landscape.
- [ ] Audio/haptics can be disabled, respect device policy and never block use.

## Science/safety
- [ ] No forbidden 'hydration percentage', 'catch up', unsupported benefit, or false 90-minute optimum claims in code/content.
- [ ] No auto-prescription of volume for heat/activity/medical illness.
- [ ] Medical fluid-management choice disables generic computed recommendations.
- [ ] No gamified rewards tied to drinking unusually large amounts.
- [ ] Every health-adjacent sentence has a reviewed evidence/policy mapping.

## Performance/privacy
- [ ] AAB/device delivery size measured and compared with <=18MB target; if exceeded, document exception and remediation before accepting.
- [ ] Background visual render loop fully stops; no excessive periodic widget refresh.
- [ ] Jank/first-use metrics recorded with Macrobenchmark on real target devices and fallback mode functioning on API26–32.
- [ ] No mandatory network request, ads ID, unneeded health/location permission; export/delete tested.
- [ ] Widget/notification content respects lock-screen privacy and OS accessibility.

## Documentation & quality
- [ ] Dependency license/security audit complete (fonts, sound, third-party skill/scripts), trademark check started.
- [ ] Source code architecture matches ADR or logged decision amendment.
- [ ] Build, tests, benchmarks, and release instructions reproducible.
- [ ] Usability test with adults who have not seen app; observe first-time logging, editing, notification expectations and interpretation of reports.
