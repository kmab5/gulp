# Implementation roadmap · practical vertical slices

## Stage 0 — project scaffolding and guardrails
Create Android Kotlin/Compose repository; write source-of-truth `PRODUCT.md`, `DESIGN.md`, `SCIENCE.md` from this bundle; Gradle version catalog; unit/UI tests, lint/static checks, baseline size report and CI. Record Android versions supported and device test matrix. Output: empty shell booting offline with four-R nav and accessible fallback.

## Stage 1 — single hero art instrument, before feature sprawl
Create a production-lean `WorldSurface` and semantic Compose overlay. Prototype Canvas-only liquid torus, 60 FPS touch ripple/drag, reduced motion, AGSL enhancement on API33+ and fallback. Validate GPU/memory/thermal on physical devices; reject artistic choices that require heavy runtime. Output: first unforgettable screen **without** needing a backend.

## Stage 2 — Ritual transaction and animation
Room schema, vessel preferences, record/edit/undo, distinct actual commit indication, one-tap log in scene, accessible controls and localized volumes. Functional before polish. Every update immediately drives world state and Reflection.

## Stage 3 — Rhythm engine and notification lifecycle
DataStore settings, inexact Android reminders, quiet hours, dismiss/snooze, process death/reboot/timezone handling, permission education, notification actions, explicit 'around' language and suppression. Test with short intervals in instrumented debug mode, not daily real-time waits.

## Stage 4 — widgets (release-blocking)
Small Sip 2×1, medium Orbit 4×2, larger Aperture; snapshot scene images, action handlers, duplicate-action protection, multi-instance resize, event-driven updates and release APK screenshots. Widget-ready from first public release.

## Stage 5 — Road and Reflection
Road progression semantics that cannot reward higher fluid volume; no punitive streaks. 7-day logged-beverage reporting, correction, export/delete, graceful missing days. Accessible static ledger alternate presentation.

## Stage 6 — aesthetic overdrive and hardening
One polished coherent motion score; sound/haptic opt-ins; content-writing pass; material and shader art finesse; language/accessibility, low battery, notification cadence and safety review. Measure size/startup/jank/memory on hardware. R8/AAB hardening and reproducible release artifacts.

## Release sequencing and design review
At every stage produce device screenshot or short capture, interaction notes, benchmark summary, tests, and size delta. Do not proceed when the main 'log a drink' task becomes less clear. Aesthetic passes are deliberately ongoing, not postponed as 'final polish'.

## Deferred experimental themes
Expandable 3D microplanet, smart bottles, Health Connect, wearables, environmental sensors, collaborative world-building. Only explore after verified core quality and medical/safety review. Do not add network/privacy creep without explicit decision.
