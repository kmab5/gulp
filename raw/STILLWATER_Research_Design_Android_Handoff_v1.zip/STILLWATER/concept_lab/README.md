# Interactive design study — NOT an Android implementation

Open `index.html` in Chrome or another desktop/mobile browser (no server, API, fonts, assets or network required). The local HTML concept demonstrates the 4Rs, organic rendered Observatory, touch/drag response, vessel selection, log and undo, responsive stage and reduced-motion behavior. Its logs exist **only in JS memory and reset on page refresh**. Its reminder text and in-app history data are fictional/conceptual. It does not schedule Android notifications, offer medical advice, store clinical records, or implement the production app.

The purpose is to communicate art direction without bundling a game engine or distributing third-party assets. Its Canvas2D engine is a disposable art study, **not** the final selected Kotlin Compose/AGSL architecture. Source is self-contained and original. Keyboard accessibility is partial because this is a sketch; the Android release criteria require full TalkBack and input alternatives.
